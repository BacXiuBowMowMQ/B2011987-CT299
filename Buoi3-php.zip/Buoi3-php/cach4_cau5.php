<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "qlsv";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
//tao chuoi luu cau lenh sql
$sql = "SELECT * FROM student";
//thuc thi cau lenh sql va dua doi tuong vao $result
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    // hiển thị dữ liệu trên trang
    while($row = mysqli_fetch_assoc($result)) {
        echo "id: " . $row["id"]. " - Hoten: " . $row["fullname"]. " " 
        . $row["email"].' ngaysinh: '.$row['Birthday']."<br>";
    }
} else {
    echo "0 results";
}

mysqli_close($conn);

?>